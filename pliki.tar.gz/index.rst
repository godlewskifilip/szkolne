.. nowy_dokument documentation master file, created by
   sphinx-quickstart on Tue Oct 28 11:26:51 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

===========================
nowy_dokument documentation
===========================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   rozdzial1/index
   rozdzial2/index
   rozdzial3/index


ROZDZIAŁ 3
===========
